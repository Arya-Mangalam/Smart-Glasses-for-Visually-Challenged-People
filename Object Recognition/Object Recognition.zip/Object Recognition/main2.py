# object Recognition
# use this file when audio feedback device is connected to laptop

import cv2
from gui_buttons import Buttons
import serial
import time
ser=serial.Serial(port='com6',baudrate=9600) #write your port name

# # Wait for Arduino to initialize
# time.sleep(0.01)

#Initialize Buttons
button = Buttons()
button.add_button("person", 20, 20)
button.add_button("bottle", 20, 80)
button.add_button("laptop", 20, 140)
button.add_button("cell phone", 20, 200)
button.add_button("book", 20, 260)

#Opencv DNN
net = cv2.dnn.readNet("dnn_model/yolov4-tiny.weights", "dnn_model/yolov4-tiny.cfg")
model = cv2.dnn_DetectionModel(net)
model.setInputParams(size=(320, 320), scale=1/255)

#Load Class Lists
classes = []
with open("dnn_model/classes.txt", "r") as file_object:
    for class_name in file_object.readlines():
        class_name = class_name.strip()
        classes.append(class_name)
print("Object List")
print(classes)


#Initialize the camera
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,1050)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT,700)
# Full HD 1920 x 1080


def click_button(event ,x ,y ,flags , params):
    global button_person
    if event == cv2.EVENT_LBUTTONDOWN:
        #print(x, y)
        button.button_click(x, y)

#Create Window
cv2.namedWindow("Frame")
cv2.setMouseCallback("Frame",click_button)

while True:
    #Get frames
    ret, frame = cap.read()
    
    #Get Active Buttons List
    active_buttons = button.active_buttons_list()
    if active_buttons==[]:        
        pass
    elif active_buttons==['person']:
        ser.write(b'02')
    # elif len(active_buttons) > 2:
    #     if active_buttons.count('person') > 1:
    #         ser.write(b'01')
    #     else:
    #         print('person and object both')
    else:
        ser.write(b'01')

    print("Active buttons",active_buttons)


    #Object Detection
    (class_ids, scores, bboxes) = model.detect(frame)
    for class_id, score, bbox in zip(class_ids, scores, bboxes):
        (x, y, w, h) = bbox
        class_name = classes[class_id]
        #change here class_id[0]

        if class_name in active_buttons:
            cv2.putText(frame, class_name, (x, y - 10), cv2.FONT_HERSHEY_PLAIN, 2, (200, 0, 50), 2)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (200, 0, 50), 3)

    #Display buttons
    button.display_buttons(frame)


        #print(x, y, w, h)
        #cv2.putText(frame, str(class_id), (x,y-10), cv2.FONT_HERSHEY_PLAIN, 2, (200,0,50),2)
        #cv2.putText(frame, class_name, (x, y - 10), cv2.FONT_HERSHEY_PLAIN, 2, (200, 0, 50), 2)
        #cv2.rectangle(frame, (x, y), (x+w, y+h), (200, 0, 50), 3)


    #print("class ids", class_ids)
    #print("scores", scores)
    #print("bboxes", bboxes)

    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1)
    if key == 27:
        # Send termination signal to Arduino
        ser.write(b'terminate\n')  # 'terminate' is the signal you can customize in your Arduino code

        # Close the serial connection
        ser.close()
        break

cap.release()
cv2.destroyAllWindows()
